<!--Registration page Start-->
  	<section class="container-fluid">
  	    <div class="container re_form">
  	        
  	        <div class="col-md-12 col-sm-12 form_part">
  	            <div class="col-md-4 col-sm-3"></div>
  	            <div class="col-md-4 col-sm-6 col-xs-12 from">
  	                <div class="row">
  	                    <form action="" method="post">
  	                        <div class="col-md-12">
  	                            <h4>Admin Login</h4>
  	                        </div>
                            
                            <div class="col-md-12">
                                <input type="text" class="simple_input" id="" name="email" placeholder="User email">
                            </div><!--Email Address part end-->

                            <div class="col-md-12">
                                <input type="password" class="simple_input" id="" name="pass" placeholder='Password'>
                            </div><!--Password part end-->

                           
                            <div class="col-md-12">
                               <span class="line"></span>
                                <input class="sing_up" id="" type="submit" value="Login" name="login">
                            </div><!--Submit part end-->
  	                    </form><!--FORM PART END-->
  	                </div>
  	            </div><!--form div part end-->
  	            <div class="col-md-3"></div>
  	        </div>
  	    </div><!--container end-->
  	</section><!--container-fluid part end-->
