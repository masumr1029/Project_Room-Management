<?php 

 $con=mysqli_connect("localhost", "root", "", "rma");
 ?>